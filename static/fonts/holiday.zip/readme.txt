Agung Rohmat - alphArt
support@alphartype.com
https://alphartype.com

-----------------------------------------------------------
FREE FOR PERSONAL USE ONLY
-----------------------------------------------------------

License Usage :

Only for PERSONAL USE !!!
No Commercial use allowed
Purchase for a commercial license through our website:
https://alphartype.com

-----------------------------------------------------------
TERMS
-----------------------------------------------------------

Commercial Use is any use:
(i) that involves an exchange of money or other consideration,
(ii) that promotes a business (e.g., sole proprietorship, corporation, or partnership), product, or service, or
(iii) where financial gain or other consideration is either sought or a result, directly or indirectly, of Licensee’s use of the Licensed Asset.
If any one or more of the criteria in (i), (ii), and (iii) is met, then the use is deemed “Commercial”.

Non-Commercial Use (Personal):
Non-commercial Use is a use for solely personal purposes; any use that meets the definition of “Commercial Use” can not be a Non-commercial use.

-----------------------------------------------------------    
-----------------------------------------------------------

YOU ARE NOT ALLOWED TO :

Sell and Redistribute
The items purchased are for your use only. You cannot sell and redistribute it to any third party.

Convert
Converting products into different formats without written permission from us.

Duplicate
You may not duplicate/copy the product to anyone without our permission.

-----------------------------------------------------------
-----------------------------------------------------------

alphArt  is a member of Indonesia Font Designers Association (Perkumpulan Desainer Huruf Indonesia (PDHI)). SK Mentri Hukum dan HAM Republik Indonesia.
Nomor: AHU-0000261.AH.01.07.Tahun 2020

ALL ACTIONS RELATING TO VIOLATIONS OF THE LAW, WILL BE PROCESSED WITH REFERENCE TO PDHI REGULATIONS. INCLUDING THE LICENSE RATES THAT APPLY AT PDHI.

-----------------------------------------------------------
-----------------------------------------------------------

INDONESIA !!! (TRANSLATE)

-----------------------------------------------------------
GRATIS UNTUK PENGGUNAAN PRIBADI SAJA
-----------------------------------------------------------

Penggunaan Lisensi:

Hanya untuk PENGGUNAAN PRIBADI !!!
Penggunaan komersial tidak diizinkan
Belilah untuk lisensi komersial melalui website kami :
https://alphartype.com

-----------------------------------------------------------
KETENTUAN/ISTILAH
-----------------------------------------------------------

Penggunaan Komersial adalah segala penggunaan:
(i) yang melibatkan pertukaran uang atau pertimbangan lain,
(ii) yang mempromosikan bisnis (mis., kepemilikan perseorangan, korporasi, atau kemitraan), produk, atau layanan, atau
(iii) di mana keuntungan finansial atau pertimbangan lain dicari atau hasilnya, secara langsung atau tidak langsung, penggunaan Aset Lisensi oleh Pemegang Lisensi.
Jika ada satu atau lebih kriteria dalam (i), (ii), dan (iii) terpenuhi, maka penggunaannya dianggap “Komersial”.

Penggunaan Non-Komersial (Pribadi):
Penggunaan Non-komersial adalah penggunaan hanya untuk tujuan pribadi; setiap penggunaan yang memenuhi definisi “Penggunaan Komersial” tidak dapat menjadi penggunaan Nonkomersial.

-----------------------------------------------------------
-----------------------------------------------------------

ANDA TIDAK DIIZINKAN UNTUK:

Jual dan Distribusi Ulang
Barang yang dibeli hanya untuk Anda gunakan. Anda tidak dapat menjual dan mendistribusikannya ke pihak ketiga mana pun.

Mengubah
Mengubah produk menjadi format yang berbeda tanpa izin tertulis dari kami.

Duplikat
Anda tidak boleh menggandakan / menyalin produk kepada siapa pun tanpa izin kami.

-----------------------------------------------------------
-----------------------------------------------------------

alphArt  adalah anggota dari Perkumpulan Desainer Huruf Indonesia (PDHI). SK Mentri Hukum dan HAM Republik Indonesia.
Nomor: AHU-0000261.AH.01.07.Tahun 2020

SEGALA TINDAKAN YANG TERKAIT PELANGGARAN HUKUM, AKAN DIPROSES DENGAN MENGINGAT PERATURAN PDHI. TERMASUK HARGA LISENSI YANG BERLAKU DI PDHI.